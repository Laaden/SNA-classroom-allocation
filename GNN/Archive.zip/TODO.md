# TODO

- Use subgraph sampling
- Uncomment plotting & use weak dependencies on plotting libraries
-- Removed purely so that compilation doesn't pull them in, but it's not a permanent solution
- PCA test topological features
